function varargout = NS_CPM(varargin)
% NS_CPM MATLAB code for NS_CPM.fig
%      NS_CPM, by itself, creates a new NS_CPM or raises the existing
%      singleton*.
%
%      H = NS_CPM returns the handle to a new NS_CPM or the handle to
%      the existing singleton*.
%
%      NS_CPM('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in NS_CPM.M with the given input arguments.
%
%      NS_CPM('Property','Value',...) creates a new NS_CPM or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before NS_CPM_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to NS_CPM_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help NS_CPM

% Last Modified by GUIDE v2.5 04-Nov-2021 22:11:38

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @NS_CPM_OpeningFcn, ...
                   'gui_OutputFcn',  @NS_CPM_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before NS_CPM is made visible.
function NS_CPM_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to NS_CPM (see VARARGIN)

% Choose default command line output for NS_CPM
% web message



handles.output = hObject;

axes(handles.axes1);
axis image;

[a]=mfilename('fullpath');
[cdir, ~ ] = fileparts(a);
figobj=get(handles.figure1);
f = imread([cdir filesep 'icon' filesep 'spider3.png'],'BackgroundColor',figobj.Color);
h =imshow(f);
set(h,'ButtonDownFcn',@my_imButtonDfcn)

movegui(hObject, 'center')
% my_imButtonDfcn

addpath([cdir filesep 'functions']);
figName = figobj.Name;
currentVersion = figName(strfind(figName,' ')+1:end);

[webcontent, WebStatus]=urlread('http://neurospider.cn/projects/NST2021a.txt');

if WebStatus
    webcontent   = strrep(webcontent,char(10),'');

    [startIndex_v,endIndex_v] = regexp(webcontent,'@=@version: ');
    [startIndex_m,endIndex_m] = regexp(webcontent,'@=@message: ');
    [startIndex_w,endIndex_w] = regexp(webcontent,'@=@weburl: ');
    NSverson  = webcontent(endIndex_v+1:startIndex_m-1);
    webmsg    = webcontent(endIndex_m+1:startIndex_w-1);
    weburl    = webcontent(endIndex_w+1:end);
    if ~isequal(currentVersion,NSverson)
         opt.Default = 'Yes';opt.Interpreter='none';
         answer=questdlg('a new version is available, would you like to update now?','update','Yes','No',opt);
         switch answer
             case 'Yes'
                 web(weburl,'-browser');
         end
                 
    else
        if ~isempty(webmsg)
            msgbox(webmsg,'modal') 
        end
    end
    
       
end


% Update handles structure
guidata(hObject, handles);

% UIWAIT makes NS_CPM wait for user response (see UIRESUME)
% uiwait(handles.figure1);
function figure1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% --- Outputs from this function are returned to the command line.
function varargout = NS_CPM_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;



function In_dat_Callback(hObject, eventdata, handles)
% hObject    handle to In_dat (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of In_dat as text
%        str2double(get(hObject,'String')) returns contents of In_dat as a double


% --- Executes during object creation, after setting all properties.
function In_dat_CreateFcn(hObject, eventdata, handles)
% hObject    handle to In_dat (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function In_sco_Callback(hObject, eventdata, handles)
% hObject    handle to In_sco (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of In_sco as text
%        str2double(get(hObject,'String')) returns contents of In_sco as a double


% --- Executes during object creation, after setting all properties.
function In_sco_CreateFcn(hObject, eventdata, handles)
% hObject    handle to In_sco (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function In_out_Callback(hObject, eventdata, handles)
% hObject    handle to In_out (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of In_out as text
%        str2double(get(hObject,'String')) returns contents of In_out as a double


% --- Executes during object creation, after setting all properties.
function In_out_CreateFcn(hObject, eventdata, handles)
% hObject    handle to In_out (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
d = uigetdir;
if ischar(d)
set(handles.In_dat,'string', d);
end
guidata(hObject, handles);


% --- Executes on button press in pushbutton2.
function pushbutton2_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
[n d]= uigetfile('*.txt');
if ischar(n)
set(handles.In_sco,'string', [d   n]);
end
guidata(hObject, handles);




function In_paral_Callback(hObject, eventdata, handles)
% hObject    handle to In_paral (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of In_paral as text
%        str2double(get(hObject,'String')) returns contents of In_paral as a double


% --- Executes during object creation, after setting all properties.
function In_paral_CreateFcn(hObject, eventdata, handles)
% hObject    handle to In_paral (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function axes1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to axes1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: place code in OpeningFcn to populate axes1


% --- Executes on mouse press over axes background.
function axes1_ButtonDownFcn(hObject, eventdata, handles)
% hObject    handle to axes1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
 

function my_imButtonDfcn(hObject, eventdata, handles)
web('http:neurospider.cn' ,'-browser')


% --- If Enable == 'on', executes on mouse press in 5 pixel border.
% --- Otherwise, executes on mouse press in 5 pixel border or over text6.
function text6_ButtonDownFcn(hObject, eventdata, handles)
% hObject    handle to text6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
web('http:neurospider.cn' ,'-browser')



function In_cov_Callback(hObject, eventdata, handles)
% hObject    handle to In_cov (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of In_cov as text
%        str2double(get(hObject,'String')) returns contents of In_cov as a double


% --- Executes during object creation, after setting all properties.
function In_cov_CreateFcn(hObject, eventdata, handles)
% hObject    handle to In_cov (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton3.
function pushbutton3_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
[n d]= uigetfile('*.txt');
if ischar(n)
set(handles.In_cov,'string', [d   n]);
end
guidata(hObject, handles);

% --- Executes on button press in pushbutton4.



function In_thresh_Callback(hObject, eventdata, handles)
% hObject    handle to In_thresh (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of In_thresh as text
%        str2double(get(hObject,'String')) returns contents of In_thresh as a double


% --- Executes during object creation, after setting all properties.
function In_thresh_CreateFcn(hObject, eventdata, handles)
% hObject    handle to In_thresh (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function In_kfold_Callback(hObject, eventdata, handles)
% hObject    handle to In_kfold (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of In_kfold as text
%        str2double(get(hObject,'String')) returns contents of In_kfold as a double


% --- Executes during object creation, after setting all properties.
function In_kfold_CreateFcn(hObject, eventdata, handles)
% hObject    handle to In_kfold (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in CV_kf.
function CV_kf_Callback(hObject, eventdata, handles)
% hObject    handle to CV_kf (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

set(handles.In_kfold,'enable', 'on');

guidata(hObject, handles);

% Hint: get(hObject,'Value') returns toggle state of CV_kf


% --- Executes on button press in CV_lo.
function CV_lo_Callback(hObject, eventdata, handles)
% hObject    handle to CV_lo (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.In_kfold,'enable', 'off');

guidata(hObject, handles);
% Hint: get(hObject,'Value') returns toggle state of CV_lo


% --- Executes on button press in checkbox1.
function checkbox1_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
if get(hObject,'Value')
    set(handles.In_perm,'enable', 'on');
else
    set(handles.In_perm,'enable', 'off');
end
% Hint: get(hObject,'Value') returns toggle state of checkbox1



function In_perm_Callback(hObject, eventdata, handles)
% hObject    handle to In_perm (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of In_perm as text
%        str2double(get(hObject,'String')) returns contents of In_perm as a double


% --- Executes during object creation, after setting all properties.
function In_perm_CreateFcn(hObject, eventdata, handles)
% hObject    handle to In_perm (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in checkbox2.
function checkbox2_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox2



function In_cvrp_Callback(hObject, eventdata, handles)
% hObject    handle to In_cvrp (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of In_cvrp as text
%        str2double(get(hObject,'String')) returns contents of In_cvrp as a double


% --- Executes during object creation, after setting all properties.
function In_cvrp_CreateFcn(hObject, eventdata, handles)
% hObject    handle to In_cvrp (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in pop_mtyp.
function pop_mtyp_Callback(hObject, eventdata, handles)
% hObject    handle to pop_mtyp (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns pop_mtyp contents as cell array
%        contents{get(hObject,'Value')} returns selected item from pop_mtyp


% --- Executes during object creation, after setting all properties.
function pop_mtyp_CreateFcn(hObject, eventdata, handles)
% hObject    handle to pop_mtyp (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



% --- Executes on button press in pushbutton4.
function pushbutton4_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
d = uigetdir;
if ischar(d)
set(handles.In_out,'string', d);
end
guidata(hObject, handles);

% --- Executes on button press in pushbutton7.
function pushbutton7_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
[n, d]= uigetfile('*.mat');
[d n]
load([d n])

set(handles.In_dat,'string',CPMcfg.path.FC);
set(handles.In_sco,'string',CPMcfg.path.scores);
set(handles.In_cov,'string',CPMcfg.path.covar  );
set(handles.In_out,'string',CPMcfg.path.output );
set(handles.In_paral,'string',CPMcfg.paralle  );
set(handles.In_thresh,'string',num2str(CPMcfg.thresh)) ;
set(handles.In_kfold,'string',CPMcfg.kfold) ;
set(handles.In_cvrp,'string',CPMcfg.cvrp );
set(handles.CV_kf,'value',CPMcfg.isKfold ) ;
set(handles.CV_lo,'value',CPMcfg.isLOOCV  );
set(handles.checkbox1,'value',CPMcfg.isPermutation);
set(handles.In_perm,'string',CPMcfg.PermutationN );
set(handles.checkbox2,'value',CPMcfg.isExportConsesus);





% --- Executes on button press in button_run.
function button_run_Callback(hObject, eventdata, handles)
% hObject    handle to button_run (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

CPMcfg.path.FC = get(handles.In_dat,'string');
CPMcfg.path.scores = get(handles.In_sco,'string');
CPMcfg.path.covar = get(handles.In_cov,'string');
CPMcfg.path.output = get(handles.In_out,'string');
CPMcfg.paralle  =  str2double(get(handles.In_paral,'string'));
CPMcfg.thresh    =  str2num(get(handles.In_thresh,'string'));
CPMcfg.kfold    =  str2double(get(handles.In_kfold,'string'));
CPMcfg.cvrp     =  str2double(get(handles.In_cvrp,'string'));
CPMcfg.isKfold  =  get(handles.CV_kf,'value');
CPMcfg.isLOOCV  =  get(handles.CV_lo,'value');
CPMcfg.isPermutation = get(handles.checkbox1,'value');
CPMcfg.PermutationN  = str2double( get(handles.In_perm,'string'));
CPMcfg.isExportConsesus = get(handles.checkbox2,'value');


contents = cellstr(get(handles.pop_mtyp,'String'));
CPMcfg.modelType = contents{get(handles.pop_mtyp,'Value')};
CPMcfg.modelTypeIdx = get(handles.pop_mtyp,'Value');
CPMcfg.lassoAlpha   = 1;
save(sprintf('NS_CPM_AutoSaveParameter_%d_%d_%d_%d_%d_%.0f',clock),'CPMcfg')


% assignin('base','CPMcfg',CPMcfg)
hm = msgbox('Reading FC data... please waiting','modal');
set(hm,'Units','pixels');
figobj = get(handles.figure1);
set(hm,'Position' , figobj.Position);
CPMcfg.mainFigurePosition = figobj.Position;

Data= NS_CPM_prepare_data(CPMcfg);
assignin('base','Data',Data)
assignin('base','CPMcfg',CPMcfg)
close(hm)
hc= NS_CPM_confirm(Data,CPMcfg);
set(hObject,'backgroundcolor',[0.8 0 0])
drawnow
uiwait(hc)


ALLPerformance = evalin('base','ALLPerformance');
msg = guiReport(ALLPerformance,CPMcfg);
set(handles.TextReport1,'string',msg.predict);
if CPMcfg.isPermutation==1
    set(handles.TextReport2,'string',msg.permu);
end
set(hObject,'backgroundcolor',[0.94 0.94 0.94])
drawnow

 
function msg = guiReport(ALLPerformance,CPMcfg)

msg.predict ='';
msg.permu  ='';
for i = 1:length(ALLPerformance)
    Performance = ALLPerformance{i};    
    if isnan(Performance.positive.r),Performance.positive.r=-9.9;Performance.positive.p=-9.9;end
    if isnan(Performance.negative.p),Performance.negative.r=-9.9;Performance.negative.p=-9.9;end
    
    msg.predict(end+1,:) = sprintf(' positive (%.4f): r=% 2.3f ; p=% 2.3f',CPMcfg.thresh(i), Performance.positive.r,Performance.positive.p);
    msg.predict(end+1,:) = sprintf(' negative (%.4f): r=% 2.3f ; p=% 2.3f',CPMcfg.thresh(i),Performance.negative.r,Performance.negative.p);
    
    if CPMcfg.isPermutation==1
        if isempty(Performance.Permutation.p_positive),Performance.Permutation.p_positive=-9.9;end
        if isempty(Performance.Permutation.p_negative),Performance.Permutation.p_negative=-9.9;end
        msg.permu(end+1,:) = sprintf(' positive (%.4f): p=% 2.3f',CPMcfg.thresh(i), Performance.Permutation.p_positive);
        msg.permu(end+1,:) = sprintf(' negative (%.4f): p=% 2.3f',CPMcfg.thresh(i), Performance.Permutation.p_negative);
    end
end

 
